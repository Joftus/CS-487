// @Author: Josh Loftus (unless a method is tagged otherwise)
public class GetLocalTime extends RPC {

	public GetLocalTime() { super("GetLocalTime", new c_int()); }
}