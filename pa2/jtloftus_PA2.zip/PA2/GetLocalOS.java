// @Author: Josh Loftus (unless a method is tagged otherwise)
public class GetLocalOS extends RPC{

	public GetLocalOS() { super("GetLocalOS", new c_char()); }
}