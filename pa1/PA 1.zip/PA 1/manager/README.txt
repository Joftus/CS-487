Manager Readme File (java)

- To Run (must be in this folder)
	1. compile (shouldn't be necessary) using: javac Manager.java && javac AgentMonitor.java && javac BeaconListener.java && javac Client.java
	2. run manager instance: java Manager
