Agent Readme File (c++)

- To Run (must be in this folder)
	1. ensure updated objects (shouldn't be necessary): make clean
	2. build project: make
	3. run project (i.e. 1 agent instance): ./agent
